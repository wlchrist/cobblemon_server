tag @s add MewtwoCaught
