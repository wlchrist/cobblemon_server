tag @s add EnteiCaught
