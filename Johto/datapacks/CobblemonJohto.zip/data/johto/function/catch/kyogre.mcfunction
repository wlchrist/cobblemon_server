tag @s add KyogreCaught
