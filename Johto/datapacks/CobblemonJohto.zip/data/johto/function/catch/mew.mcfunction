tag @s add MewCaught
