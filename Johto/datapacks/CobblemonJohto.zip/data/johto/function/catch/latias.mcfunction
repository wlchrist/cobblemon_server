tag @s add LatiasCaught
