tag @s add RayquazaCaught
