tag @s add LugiaCaught
