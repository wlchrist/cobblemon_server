tag @s add GiratinaCaught
