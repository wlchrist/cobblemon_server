tag @s add DialgaCaught
